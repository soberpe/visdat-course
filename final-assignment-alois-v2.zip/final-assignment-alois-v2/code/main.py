from __future__ import annotations

import sys
from pathlib import Path
import numpy as np

from PyQt6.QtCore import QTimer
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
    QLabel, QPushButton, QLineEdit, QFileDialog, QSpinBox, QDoubleSpinBox,
    QTabWidget, QListWidget, QMessageBox, QGroupBox, QCheckBox
)

import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

from pyvistaqt import QtInteractor

from src.io_lvm import load_lvm_time_force_acc
from src.frf_analysis import (
    estimate_fs, compute_frf_h1_and_coherence, avg_magnitude,
    pick_modes_peak_picking, participation_vector_windowed
)
from src.geometry import building_points_12, building_edges_12
from src.viewer3d import build_frame, points_poly, deform
from src.exporting import save_figure_png, save_gif


# -----------------------------
# Matplotlib canvases
# -----------------------------

class FRFCanvas(FigureCanvas):
    """Magnitude + phase."""
    def __init__(self):
        fig = Figure(figsize=(6, 4))
        self.ax_mag = fig.add_subplot(211)
        self.ax_ph = fig.add_subplot(212, sharex=self.ax_mag)
        super().__init__(fig)

class CoherenceCanvas(FigureCanvas):
    """Coherence plot (0..1)."""
    def __init__(self):
        fig = Figure(figsize=(6, 3))
        self.ax = fig.add_subplot(111)
        super().__init__(fig)


# -----------------------------
# Main window
# -----------------------------

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Hochhaus – Moden (FRF) & 3D (V2)")

        # ===== Data containers =====
        self.frfs: list[np.ndarray] = []        # 6x complex FRFs (one per excitation point)
        self.coherences: list[np.ndarray] = []  # 6x coherence arrays
        self.f: np.ndarray | None = None
        self.mode_indices: np.ndarray = np.array([], dtype=int)

        # ===== 3D model (12 nodes) =====
        self.points0 = building_points_12(depth=0.6)
        self.edges = building_edges_12()
        self.frame_mesh = build_frame(self.points0, self.edges)

        self.direction = np.array([1.0, 0.0, 0.0])  # measured direction (only 1 direction exists)
        self.v_complex = np.ones(12, dtype=complex)  # will be updated when selecting a mode
        self.omega = 2*np.pi*5.0
        self.t = 0.0

        # ===== Export folder =====
        self.export_dir = Path(__file__).resolve().parents[1] / "assets" / "screenshots"
        self.export_dir.mkdir(parents=True, exist_ok=True)

        # -----------------------------------------------------
        # Left side: files + parameters + export
        # -----------------------------------------------------
        left = QWidget()
        left_layout = QVBoxLayout(left)

        files_box = QGroupBox("Messdateien (.lvm) – Anregung Punkt 1..6 (Response immer Punkt 1)")
        grid = QGridLayout(files_box)
        self.file_edits: list[QLineEdit] = []
        for i in range(6):
            edit = QLineEdit()
            edit.setPlaceholderText("Datei wählen …")
            btn = QPushButton("Browse")
            btn.clicked.connect(lambda _, k=i: self.browse_file(k))
            self.file_edits.append(edit)
            grid.addWidget(QLabel(f"Punkt {i+1}"), i, 0)
            grid.addWidget(edit, i, 1)
            grid.addWidget(btn, i, 2)
        left_layout.addWidget(files_box)

        params_box = QGroupBox("Analyse-Parameter")
        pgrid = QGridLayout(params_box)

        self.n_modes = QSpinBox()
        self.n_modes.setRange(1, 10)
        self.n_modes.setValue(5)

        self.fmax = QDoubleSpinBox()
        self.fmax.setRange(1.0, 2000.0)
        self.fmax.setValue(60.0)
        self.fmax.setSuffix(" Hz")

        self.prom = QDoubleSpinBox()
        self.prom.setRange(0.001, 1.0)
        self.prom.setDecimals(3)
        self.prom.setSingleStep(0.01)
        self.prom.setValue(0.05)

        # NEW: frequency half-window around peak for robust complex averaging
        self.peak_band = QDoubleSpinBox()
        self.peak_band.setRange(0.0, 50.0)
        self.peak_band.setDecimals(2)
        self.peak_band.setSingleStep(0.1)
        self.peak_band.setValue(0.3)
        self.peak_band.setSuffix(" Hz")

        self.scale = QDoubleSpinBox()
        self.scale.setRange(0.01, 20.0)
        self.scale.setValue(1.0)
        self.scale.setSingleStep(0.1)

        self.show_all_coh = QCheckBox("Alle Kohärenzen plotten (sonst nur Mittelwert)")
        self.show_all_coh.setChecked(False)
        self.show_all_coh.stateChanged.connect(self.update_coherence_plot)

        pgrid.addWidget(QLabel("Anzahl Moden:"), 0, 0)
        pgrid.addWidget(self.n_modes, 0, 1)
        pgrid.addWidget(QLabel("fmax Peak-Picking:"), 1, 0)
        pgrid.addWidget(self.fmax, 1, 1)
        pgrid.addWidget(QLabel("Prominence (rel.):"), 2, 0)
        pgrid.addWidget(self.prom, 2, 1)
        pgrid.addWidget(QLabel("Peak-Band (±):"), 3, 0)
        pgrid.addWidget(self.peak_band, 3, 1)
        pgrid.addWidget(QLabel("3D Scale:"), 4, 0)
        pgrid.addWidget(self.scale, 4, 1)
        pgrid.addWidget(self.show_all_coh, 5, 0, 1, 2)

        left_layout.addWidget(params_box)

        self.btn_analyze = QPushButton("Load & Analyze")
        self.btn_analyze.clicked.connect(self.load_and_analyze)
        left_layout.addWidget(self.btn_analyze)

        export_box = QGroupBox("Export")
        ex = QGridLayout(export_box)
        self.btn_export_frf = QPushButton("Export FRF Plot (PNG)")
        self.btn_export_frf.clicked.connect(self.export_frf_png)
        self.btn_export_3d = QPushButton("Export 3D Screenshot (PNG)")
        self.btn_export_3d.clicked.connect(self.export_3d_png)
        self.btn_export_gif = QPushButton("Export 3D Animation (GIF)")
        self.btn_export_gif.clicked.connect(self.export_3d_gif)

        ex.addWidget(self.btn_export_frf, 0, 0, 1, 2)
        ex.addWidget(self.btn_export_3d, 1, 0, 1, 2)
        ex.addWidget(self.btn_export_gif, 2, 0, 1, 2)

        left_layout.addWidget(export_box)
        left_layout.addStretch(1)

        # -----------------------------------------------------
        # Right side: tabs
        # -----------------------------------------------------
        self.tabs = QTabWidget()

        frf_tab = QWidget()
        frf_layout = QVBoxLayout(frf_tab)
        self.frf_canvas = FRFCanvas()
        frf_layout.addWidget(self.frf_canvas)
        self.tabs.addTab(frf_tab, "FRFs")

        coh_tab = QWidget()
        coh_layout = QVBoxLayout(coh_tab)
        self.coh_canvas = CoherenceCanvas()
        coh_layout.addWidget(self.coh_canvas)
        self.tabs.addTab(coh_tab, "Kohärenz")

        modes_tab = QWidget()
        modes_layout = QVBoxLayout(modes_tab)
        modes_layout.addWidget(QLabel("Gefundene Moden (Peak-Picking auf Mittelwert |H|):"))
        self.mode_list = QListWidget()
        self.mode_list.currentRowChanged.connect(self.on_mode_selected)
        modes_layout.addWidget(self.mode_list)
        self.tabs.addTab(modes_tab, "Moden")

        view_tab = QWidget()
        view_layout = QVBoxLayout(view_tab)
        self.plotter = QtInteractor(view_tab)
        self.plotter.set_background("white")  # requested: bright background
        view_layout.addWidget(self.plotter.interactor)
        self.tabs.addTab(view_tab, "3D")

        # -----------------------------------------------------
        # Main layout
        # -----------------------------------------------------
        main = QWidget()
        main_layout = QHBoxLayout(main)
        main_layout.addWidget(left, 1)
        main_layout.addWidget(self.tabs, 2)
        self.setCentralWidget(main)

        # -----------------------------------------------------
        # 3D setup: black lines on bright background
        # -----------------------------------------------------
        self.plotter.add_mesh(self.frame_mesh, color="black", line_width=6)
        self.points_actor = self.plotter.add_mesh(
            points_poly(self.points0),
            color="orange",
            point_size=16,
            render_points_as_spheres=True
        )
        self.plotter.show_axes()
        self.plotter.reset_camera()

        # Animation timer
        self.timer = QTimer()
        self.timer.timeout.connect(self.animate_step)

        # Keep plots auto-scaled to fmax
        self.fmax.valueChanged.connect(self.update_frf_plot)
        self.fmax.valueChanged.connect(self.update_coherence_plot)

    # =====================================================
    # Actions
    # =====================================================

    def browse_file(self, idx: int):
        p, _ = QFileDialog.getOpenFileName(
            self, "Select .lvm file", str(Path.cwd()),
            "LabVIEW Measurement (*.lvm);;All Files (*)"
        )
        if p:
            self.file_edits[idx].setText(p)

    def _resolve_paths(self) -> list[str]:
        """If no file is selected, try using bundled sample data."""
        paths = []
        for i in range(6):
            p = self.file_edits[i].text().strip()
            if not p:
                sample = Path(__file__).parent / "data" / "sample" / f"Time 1-{i+1}.lvm"
                if sample.exists():
                    p = str(sample)
                    self.file_edits[i].setText(p)
                else:
                    raise ValueError(f"Bitte Datei für Punkt {i+1} auswählen.")
            paths.append(p)
        return paths

    def load_and_analyze(self):
        try:
            paths = self._resolve_paths()

            self.frfs.clear()
            self.coherences.clear()
            self.f = None

            # Load each file and compute FRF + coherence
            for p in paths:
                df = load_lvm_time_force_acc(p)
                fs = estimate_fs(df["t_s"].to_numpy())

                f, H, coh = compute_frf_h1_and_coherence(
                    df["acc_g"].to_numpy(),
                    df["force_N"].to_numpy(),
                    fs=fs,
                    nperseg=4096
                )

                if self.f is None:
                    self.f = f
                else:
                    if len(f) != len(self.f) or np.max(np.abs(f - self.f)) > 1e-6:
                        raise ValueError("Frequenzraster nicht identisch (Interpolation kann man später ergänzen).")

                self.frfs.append(H)
                self.coherences.append(coh)

            # Peak picking on mean magnitude
            M = avg_magnitude(self.frfs)
            self.mode_indices = pick_modes_peak_picking(
                self.f, M,
                n_modes=self.n_modes.value(),
                fmax=float(self.fmax.value()),
                prominence_rel=float(self.prom.value())
            )

            self.mode_list.clear()
            for k, idx in enumerate(self.mode_indices, start=1):
                self.mode_list.addItem(f"Mode {k}: f = {self.f[idx]:.3f} Hz")

            # Update plots
            self.update_frf_plot()
            self.update_coherence_plot()

            if self.mode_indices.size > 0:
                self.mode_list.setCurrentRow(0)

            QMessageBox.information(self, "OK", "Analyse fertig: FRFs + Kohärenz + Moden.")
        except Exception as e:
            QMessageBox.critical(self, "Fehler", str(e))

    # =====================================================
    # Plot updates
    # =====================================================

    def update_frf_plot(self):
        if self.f is None or not self.frfs:
            return

        fmax = float(self.fmax.value())
        mask = self.f <= fmax

        ax_mag = self.frf_canvas.ax_mag
        ax_ph = self.frf_canvas.ax_ph
        ax_mag.clear()
        ax_ph.clear()

        for H in self.frfs:
            ax_mag.plot(self.f[mask], np.abs(H)[mask], alpha=0.30)

        M = avg_magnitude(self.frfs)
        ax_mag.plot(self.f[mask], M[mask], linewidth=2)
        ax_mag.set_ylabel("|H(f)| (acc/force)")
        ax_mag.grid(True)
        ax_mag.set_xlim(0, fmax)

        ph0 = np.unwrap(np.angle(self.frfs[0]))
        ax_ph.plot(self.f[mask], ph0[mask])
        ax_ph.set_xlabel("f [Hz]")
        ax_ph.set_ylabel("Phase [rad]")
        ax_ph.grid(True)
        ax_ph.set_xlim(0, fmax)

        self.frf_canvas.draw()

    def update_coherence_plot(self):
        if self.f is None or not self.coherences:
            return

        fmax = float(self.fmax.value())
        mask = self.f <= fmax

        ax = self.coh_canvas.ax
        ax.clear()

        if self.show_all_coh.isChecked():
            for coh in self.coherences:
                ax.plot(self.f[mask], coh[mask], alpha=0.30)

        coh_mean = np.mean(np.vstack(self.coherences), axis=0)
        ax.plot(self.f[mask], coh_mean[mask], linewidth=2)
        ax.set_xlabel("f [Hz]")
        ax.set_ylabel("Kohärenz γ²")
        ax.set_ylim(0.0, 1.05)
        ax.grid(True)
        ax.set_xlim(0, fmax)

        self.coh_canvas.draw()

    # =====================================================
    # Mode selection & 3D animation
    # =====================================================

    def on_mode_selected(self, row: int):
        if row < 0 or self.f is None or not self.frfs or self.mode_indices.size == 0:
            return

        idx_center = int(self.mode_indices[row])
        f_mode = float(self.f[idx_center])

        # NEW: complex averaging in ±peak_band around the peak (stabilizes values)
        band = float(self.peak_band.value())
        v6 = participation_vector_windowed(self.frfs, self.f, idx_center, band_hz=band, ref=0)

        # 12-node building: mirror front(6) to back(6)
        self.v_complex = np.concatenate([v6, v6], axis=0)

        # update animation frequency
        self.omega = 2*np.pi*f_mode
        self.t = 0.0

        # color nodes by amplitude
        self._update_3d_points(self.points0, np.abs(self.v_complex))

        if not self.timer.isActive():
            self.timer.start(16)

    def animate_step(self):
        self.t += 0.016

        pts_def = deform(
            self.points0, self.v_complex, self.direction,
            t=self.t, omega=self.omega, scale=float(self.scale.value())
        )

        # update frame geometry
        self.frame_mesh.points = pts_def

        # update points
        self._update_3d_points(pts_def, np.abs(self.v_complex))

    def _update_3d_points(self, points: np.ndarray, scalars: np.ndarray):
        try:
            self.plotter.remove_actor(self.points_actor)
        except Exception:
            pass

        self.points_actor = self.plotter.add_mesh(
            points_poly(points, scalars=scalars),
            scalars="amp",
            cmap="viridis",
            point_size=16,
            render_points_as_spheres=True
        )
        self.plotter.render()

    # =====================================================
    # Export
    # =====================================================

    def export_frf_png(self):
        try:
            out = self.export_dir / "frf_plot.png"
            save_figure_png(self.frf_canvas.figure, out)
            QMessageBox.information(self, "Export", f"FRF Plot gespeichert: {out}")
        except Exception as e:
            QMessageBox.critical(self, "Export-Fehler", str(e))

    def export_3d_png(self):
        try:
            out = self.export_dir / "3d_view.png"
            self.plotter.screenshot(str(out))
            QMessageBox.information(self, "Export", f"3D Screenshot gespeichert: {out}")
        except Exception as e:
            QMessageBox.critical(self, "Export-Fehler", str(e))

    def export_3d_gif(self):
        try:
            if self.f is None or self.mode_indices.size == 0:
                raise ValueError("Bitte zuerst analysieren und eine Mode auswählen.")

            fps = 30
            seconds = 3.0
            n_frames = int(fps * seconds)
            dt = 1.0 / fps

            frames = []
            for k in range(n_frames):
                t = k * dt
                pts_def = deform(
                    self.points0, self.v_complex, self.direction,
                    t=t, omega=self.omega, scale=float(self.scale.value())
                )
                self.frame_mesh.points = pts_def
                self._update_3d_points(pts_def, np.abs(self.v_complex))

                img = self.plotter.screenshot(return_img=True)
                if img is None:
                    raise RuntimeError("Screenshot returned None.")
                if img.shape[-1] == 4:
                    img = img[..., :3]
                frames.append(img.astype(np.uint8))

            out = self.export_dir / "3d_animation.gif"
            save_gif(frames, out, fps=fps)
            QMessageBox.information(self, "Export", f"GIF gespeichert: {out}")
        except Exception as e:
            QMessageBox.critical(self, "Export-Fehler", str(e))


def main():
    app = QApplication(sys.argv)
    w = MainWindow()
    w.resize(1350, 750)
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
