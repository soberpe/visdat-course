from __future__ import annotations

"""Matplotlib canvases embedded in a PyQt6 application."""

import matplotlib

# Use Qt backend for embedding into PyQt6.
matplotlib.use("QtAgg")

from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

import numpy as np


class FRFCanvas(FigureCanvas):
    """Canvas showing FRF magnitude (top) and phase (bottom)."""

    def __init__(self):
        fig = Figure(figsize=(6, 4))
        self.ax_mag = fig.add_subplot(211)
        self.ax_ph = fig.add_subplot(212, sharex=self.ax_mag)
        super().__init__(fig)


class Mode2DCanvas(FigureCanvas):
    """Canvas showing a static 2D mode shape (mean left/right per floor)."""

    def __init__(self):
        fig = Figure(figsize=(5, 4), constrained_layout=True)
        super().__init__(fig)
        self.ax = fig.add_subplot(111)
        self.ax.set_xlabel("normalized displacement")
        self.ax.set_ylabel("height (normalized)")
        self.ax.grid(True, alpha=0.3)

    def plot_mode(self, z: np.ndarray, u: np.ndarray, title: str = "Mode shape (2D)") -> None:
        """Plot displacement u over height z."""
        self.ax.clear()
        self.ax.plot(u, z, marker="o")
        self.ax.axvline(0.0, linewidth=1, alpha=0.6)
        self.ax.set_xlabel("normalized displacement")
        self.ax.set_ylabel("height (normalized)")
        self.ax.set_title(title)
        self.ax.grid(True, alpha=0.3)

        umax = float(np.max(np.abs(u))) if np.size(u) else 1.0
        if umax <= 0:
            umax = 1.0
        self.ax.set_xlim(-1.1 * umax, 1.1 * umax)
        self.ax.set_ylim(0.0, 1.0)
        self.draw()
